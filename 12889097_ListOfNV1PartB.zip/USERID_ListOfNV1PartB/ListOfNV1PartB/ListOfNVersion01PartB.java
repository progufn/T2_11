/**
 * This class maintains an arbitrary length list of integers.
 * 
 * In this version 1:
 * 1. The size of the list is fixed after the object is created.
 * 2. The code assumes there is at least one element in the list.
 * 
 * This class introduces the use of loops.
 * 
 * @author Raymond Lister 
 * @version September 2014
 * 
 */
public class ListOfNVersion01PartB
{   
    private int[] list;  // Note: no "= {0, 1, 2, 3}" now

    /**
     * This constructor initializes the list to the same values
     * as in the parameter.
     *
     * @param  element   the initial elements for the list
     */
    public ListOfNVersion01PartB(int [] element)
    {
        // with constant subscripts for ListOf4...
        // list[0] = element[0];
        // list[1] = element[1];
        // list[2] = element[2];
        // list[3] = element[3];

        // with variable subscripts for ListOf4 ... 
        // 1. Initialisation to start the "loop" ...
        // int i = 0; // role: stepper 

        // list[i] = element[i];
        // i = i+1;              // 3. changes to "i" inside the "loop"
        // list[i] = element[i]; //    eventually stops the loop. 
        // i = i+1;
        // list[i] = element[i];
        // i = i+1;
        // list[i] = element[i]; //   2. "loop" terminates at end of array.

        // with a loop for ListOfN ... 

        /* delete this comment line

        // make "list" be an array the same size as "element"
        list = new typeOfElements[sizeOfArray];

        // This loop copies the values from "element" to "list"
        for ( int i=xxx ; xxxxxxxxxx ; xxx ) 
        {
        xxxxxxxxxxx
        }

        delete this comment line */  

    } // constructor ListOfNVersion01Skeleton(int [] element)

    /**
     * @return     the first element in the list 
     */
    public int getFirst()
    {
        return list[0];

    } // method getFirst

    /**
     * In ListOfN in this test, the toString method
     * should return a String such that:
     * 
     * 1. The String begins with an open brace "{" followed
     *    IMMEDIATELY (i.e. no space) by the first element
     *    of the list.
     * 2. All remaining elements of the list are preceded by
     *    ", " (i.e. a comma folowed by a SINGLE space).
     * 3. The String ends with a closing brace "}".
     *
     * e.g. "{1, 2, 3, 4}"
     * 
     * @return     A summary of the contents of the list.
     */
    public String toString()
    {
        String s = "{" + list[0]; // role: gatherer

        // with constant subscripts for ListOf4 ...      
        // s = s + ", " + list[1];      
        // s = s + ", " + list[2];      

        // with variable subscripts for ListOf4 ... 
        // int i = 1;      // role: stepper
        // s = s + ", " + list[i];
        // i = i+1;
        // s = s + ", " + list[i];
        // i = i+1;
        // s = s + ", " + list[i];   

        // with a loop for ListOfN ... 
        /* delete this comment line      
        for ( int i=xxx ; xxxxxxxxxx ; xxx ) 
        {
           xxxxxxxxxxx
        }

        s = s + "}";
        delete this comment line */ 

        return s;

    } // method toString

    /**
     * @return     the sum of the elements of the array
     */
    public int sum()
    {
        int sum = 0; // role: gatherer

        // with constant subscripts for ListOf4 ...     
        // sum = sum + list[0];  // shorter way is sum += list[0];
        // sum = sum + list[1];
        // sum = sum + list[2];
        // sum = sum + list[3];

        // with variable subscripts for ListOf4 ... 
        // int i = 0; // role: stepper
        // 
        // sum = sum + list[i];  // shorter way is sum += list[i];
        // ++i;
        // sum = sum + list[i];
        // ++i;
        // sum = sum + list[i];
        // ++i;
        // sum = sum + list[i];

        // with a loop for ListOfN ... 
        /* delete this comment line      
        for ( int i=xxx ; xxxxxxxxxx ; xxx ) 
        {
           xxxxxxxxxxx
        }
        delete this comment line */ 

        return sum;

    } // method sum 

    /**
     * @return     the number of times the replacement was made (i.e. 0 or 1)
     * 
     * @param  replaceThis   the element to be replaced
     * @param  withThis      the replacement
     */
    public int replaceOnce(int replaceThis, int withThis)
    {        
        // with constant subscripts for ListOf4 ...           
        // if ( list[0] == replaceThis )
        // {
        //    list[0] = withThis;
        //    return 1;
        // }
        // 
        // if ( list[1] == replaceThis )
        // {
        //    list[1] = withThis;
        //    return 1;
        // }
        // 
        // if ( list[2] == replaceThis )
        // {
        //    list[2] = withThis;
        //    return 1;
        // }
        // 
        // if ( list[3] == replaceThis ) 
        // {
        //    list[3] = withThis;
        //    return 1;
        // }
        // 
        // return 0;

        // with variable subscripts for ListOf4 ... 
        // int i = 0; // role: stepper
        // 
        // if ( list[i] == replaceThis )
        // {
        //    list[i] = withThis;
        //    return 1;
        // }
        // 
        // ++i;
        // 
        // if ( list[i] == replaceThis )
        // {
        //    list[i] = withThis;
        //    return 1;
        // }
        // 
        // ++i;
        // 
        // if ( list[i] == replaceThis )
        // {
        //    list[i] = withThis;
        //    return 1;
        // }
        // 
        // ++i;
        // 
        // if ( list[i] == replaceThis )
        // {
        //    list[i] = withThis;
        //    return 1;
        // }
        // 
        // ++i;
        //
        // return 0;

        // with a loop for ListOfN ... 
        /* delete this comment line      
        for ( int i=xxx ; xxxxxxxxxx ; xxx ) 
        {
           xxxxxxxxxxx
        }
        delete this comment line */ 

        return 0;

    } // method replaceOnce 

    /**
     * @return     the value of the smallest element in the array
     */
    public int minVal()
    {
        int mostWantedHolder = list[0];  // role: Most-wanted holder        

        // with constant subscripts for ListOf4 ...           
        // if ( list[1] < mostWantedHolder )
        //    mostWantedHolder = list[1];
        // if ( list[2] < mostWantedHolder )
        //    mostWantedHolder = list[2];
        // if ( list[3] < mostWantedHolder )
        //    mostWantedHolder = list[3];
        // return mostWantedHolder;

        // with variable subscripts for ListOf4 ... 
        // int i = 1; // role: stepper
        //
        // if ( list[i] < mostWantedHolder )
        // {
        //    mostWantedHolder = list[i];
        // }
        //
        // ++i;
        //
        // if ( list[i] < mostWantedHolder )
        // {
        //    mostWantedHolder = list[i];
        // }
        //
        // ++i;
        //
        // if ( list[i] < mostWantedHolder )
        // {
        //    mostWantedHolder = list[i];
        // }
        //
        // return mostWantedHolder;

        // with a loop for ListOfN ... 
        /* delete this comment line      
        for ( int i=xxx ; xxxxxxxxxx ; xxx ) 
        {
           xxxxxxxxxxx
        }
        delete this comment line */ 

        return mostWantedHolder;

        /* Exercise for students: implement the analogous method "maxVal", both
         * with constant subscripts for ListOf4, as shown above, and with a variable
         * subscript, as required in the previous exercise above.  The method
         * "maxVal" is examinable.
         */

    } // method minVal

    /**
     * Inserts an element in the first position. The elements already in the
     * list are pushed up one place, and the element that was previously
     * last is lost from the list.
     * 
     * @param  newElement   the element to be inserted
     */
    public void insertFirst(int newElement)
    {   
        // with constant subscripts for ListOf4 ... 
        // list[3] = list[2]; 
        // list[2] = list[1]; 
        // list[1] = list[0];
        // list[0] = newElement;

        // with variable subscripts for ListOf4 ...
        // int i; // role: stepper
        // First version         |  Second version
        // i = 3;                |  i = 2;
        // list[i] = list[i-1];  |  list[i+1] = list[i];
        // --i;
        // list[i] = list[i-1];  |  list[i+1] = list[i];
        // --i;
        // list[i] = list[i-1];  |  list[i+1] = list[i];
        // list[0] = newElement;

        // with a loop for ListOfN ... 
        /* delete this comment line      
        for ( int i=xxx ; xxxxxxxxxx ; xxx ) 
        {
           xxxxxxxxxxx
        }
        list[0] = newElement;

        delete this comment line */ 

    } // method insertFirst
    
    /*
     *  This method is NOT examinable in this test.
     *  
     *  Swaps two elements in the list.
     *  
     * @param  i   the position of one of the elements to be swapped
     * @param  j   the position of one of the elements to be swapped
     */
    private void swap(int i, int j)
    {
        int temp; // role: temporary

        temp = list[i];
        list[i] = list[j];
        list[j] = temp;

    } // method swap

    /**
     * "So the first shall be last, and the last first"
     *  -- The Christian Bible, book of Matthew 20:16
     */
    public void reverse()
    {
        // with constant subscripts for ListOf4 ...
        // swap(0, 3);
        // swap(1, 2);

        // with variable subscripts for ListOf4 ...
        // int i = 0; // role: stepper
        // int j = 3; // role: stepper
        // swap(i, j);
        // ++i;
        // --j;
        // swap(i, j);

        // with a loop for ListOfN ... 
        /* delete this comment line   
        int i = xxxxx; // role: stepper
        int j = xxxxx; // role: stepper

        while ( xxxxxxx )
        {
        xxxxxxxxxxxxxx
        }
        delete this comment line */

    } // method reverse

    /* 
     * ... several methods NOT examinable in this test
     *     have been deleted.
     */

} // class ListOfNVersion01PartB
